EasySocial.require()
	.script("story/polls")
	.done(function($)
	{
		var plugin = story.addPlugin("polls");
	});
