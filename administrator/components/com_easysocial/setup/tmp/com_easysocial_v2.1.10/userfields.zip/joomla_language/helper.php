<?php
/**
* @package      EasySocial
* @copyright    Copyright (C) 2010 - 2017 Stack Ideas Sdn Bhd. All rights reserved.
* @license      GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');

class SocialLanguageHelper
{
	/**
	 * Retrieve available joomla languages
	 *
	 * @since   2.1
	 * @access  public
	 */
	public static function getLanguages($selected = '', $subname = true)
	{
		$languages = JLanguageHelper::createLanguageList($selected , constant('JPATH_SITE'), true, true);
		$results = array();

		// Retrieve the correct metadata for the language
		foreach ($languages as $language) {
			$metaLanguage = JLanguageHelper::getMetadata($language['value']);

			$obj = new stdClass();
			$obj->text = $metaLanguage['name'];
			$obj->value = $language['value'];

			$results[] = $obj;
		}

		if (!$subname) {
			for ($i = 0; $i < count($results); $i++) {
				$results[$i]->text = preg_replace('#\(.*?\)#i', '', $results[$i]->text);
			}
		}

		return $results;
	}
}