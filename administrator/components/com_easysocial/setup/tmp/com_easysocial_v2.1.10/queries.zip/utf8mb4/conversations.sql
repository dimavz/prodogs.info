/**
* @package      EasySocial
* @copyright    Copyright (C) 2010 - 2017 Stack Ideas Sdn Bhd. All rights reserved.
* @license      GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

CREATE TABLE IF NOT EXISTS `#__social_conversations_message` (
	`id` bigint(20) NOT NULL AUTO_INCREMENT,
	`conversation_id` bigint(20) NOT NULL,
	`type` varchar(200) NOT NULL,
	`message` text CHARACTER SET utf8mb4,
	`created` datetime NOT NULL,
	`created_by` bigint(20) NOT NULL,
	PRIMARY KEY (`id`),
	KEY `conversation_id` (`conversation_id`),
	KEY `created_by` (`created_by`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;