import chatWindow from './chat/window';
import chatWindowInput from './chat/window-input';
import chatWindowAdduser from './chat/window-adduser';

export default {
    chatWindow,
    chatWindowInput,
    chatWindowAdduser
};
