require.config({
	deps: [ 'init' ]
});
